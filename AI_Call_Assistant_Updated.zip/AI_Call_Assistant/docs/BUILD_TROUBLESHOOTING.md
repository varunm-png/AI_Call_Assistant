# Android build troubleshooting

## GitHub Actions

The included workflow installs:
- Temurin JDK 17
- Android SDK platform 35
- Android Build Tools 35.0.0
- Gradle 8.9

Then it runs `gradle assembleDebug`.

If the workflow fails, open the failed step and copy the first `FAILURE:` block.

## Local Android Studio

Open `android-app` as the project root. Use JDK 17 for Gradle. Let Android Studio download missing SDK components.

## Backend URL

The debug build currently points to `http://10.0.2.2:8000/`, which is correct for an Android emulator accessing a FastAPI server on the host machine. For a physical phone, change `API_BASE_URL` to the PC's LAN address and keep the development cleartext network configuration only for local testing.

## Production

Use HTTPS, authenticated APIs, encrypted recordings and a compliant telephony provider/media bridge before production deployment.
